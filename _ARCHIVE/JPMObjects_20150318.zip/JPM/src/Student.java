
public class Student extends Person
{
	private String studentType;
	
	public void searchJobs()
	{
		return;
	}

	public String getStudentType()
	{
		return studentType;
	}

	public void setStudentType(String studentType) 
	{
		this.studentType = studentType;
	}
}
