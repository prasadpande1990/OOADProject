
public interface JobService
{
	public void postJob();
	public void searchProfile();
}
