
public class ProfessorProfile extends Profile
{
	private String researchInterest;

	public String getResearchInterest() 
	{
		return researchInterest;
	}

	public void setResearchInterest(String researchInterest) 
	{
		this.researchInterest = researchInterest;
	}
}
