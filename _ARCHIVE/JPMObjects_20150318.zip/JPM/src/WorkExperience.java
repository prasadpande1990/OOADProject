
public class WorkExperience
{
	private String employer;
	private String designation;
	private float period;
	
	// add new work experience
	public void addNewWorkExp()
	{
		
	}
	
	// remove experience details
	public boolean removeExpDetails()
	{
		return true;
	}

	public String getEmployer() 
	{
		return employer;
	}

	public void setEmployer(String employer) 
	{
		this.employer = employer;
	}

	public String getDesignation() 
	{
		return designation;
	}

	public void setDesignation(String designation) 
	{
		this.designation = designation;
	}

	public float getPeriod() 
	{
		return period;
	}

	public void setPeriod(float period) 
	{
		this.period = period;
	}
}
