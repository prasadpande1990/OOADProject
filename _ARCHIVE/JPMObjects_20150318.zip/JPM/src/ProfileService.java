
public interface ProfileService
{
	public void editProfile();
	public void displayProfile();
}
