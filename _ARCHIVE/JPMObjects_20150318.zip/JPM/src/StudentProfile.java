
public class StudentProfile extends Profile
{
	private Course courseList;

	public Course getCourseList() 
	{
		return courseList;
	}

	public void setCourseList(Course courseList)
	{
		this.courseList = courseList;
	}
}
